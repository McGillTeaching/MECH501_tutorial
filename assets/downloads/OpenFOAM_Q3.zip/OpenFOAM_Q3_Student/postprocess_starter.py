"""One profile example; extend for the assignment. Needs numpy, pandas, matplotlib."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('case',type=Path,help='e.g. 01_kEpsilon_wallFunctions/step')
p.add_argument('--station',default='6',choices=['0.2','3','6','9','12'])
a=p.parse_args()
root=Path(__file__).resolve().parent
files=list((a.case/'postProcessing/velocityProfiles').glob(f'*/xLine_{a.station}h_U.xy'))
if not files:raise SystemExit('No sampled profile found; run velocityProfiles first.')
f=max(files,key=lambda x:float(x.parent.name))
v=np.loadtxt(f,ndmin=2)
if v.shape[1]!=6:raise ValueError('Expected x,y,z,Ux,Uy,Uz columns; inspect the file.')
v=v[np.argsort(v[:,1])]
ref=pd.read_csv(root/f'DNS_data/velocityProfiles/xLine_{a.station}h.csv')
fig,ax=plt.subplots()
ax.plot(v[:,3]/2.0424,v[:,1]/0.1,label=f'RANS, iteration {f.parent.name}')
ax.plot(ref.UMean,ref.y,'ko',ms=3,label='DNS')
ax.set(xlabel='U/Ub',ylabel='y/h',title=f'x/h={a.station}')
ax.legend();fig.tight_layout();fig.savefig(a.case/f'profile_{a.station}h.png',dpi=160)
# Extend: overlay other configurations, repeat stations, plot residual/yPlus histories,
# and identify the main downstream-wall shear crossing using its coordinates.
