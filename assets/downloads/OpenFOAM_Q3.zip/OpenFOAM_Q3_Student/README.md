# Assignment 3 Q3: student cases

Three incomplete step-case configurations are supplied:

- 01_kEpsilon_wallFunctions/step: k-epsilon with wall functions, 6820 cells.
- 02_SST_wallResolved/step: wall-resolved SST, 32240 cells.
- 03_SST_wallFunctions/step: SST with wall functions, 6820 cells.

Meshes, numerical settings and mesh-specific inlet data are supplied. No precursor simulation or inlet mapping is required. No grid-convergence study is required. Do not change the mesh dictionaries or supplied inlet files: the inlet samples match the supplied meshes.

## Complete the setup

1. Replace SET_MODEL in each constant/turbulenceProperties with the appropriate model.
2. Inspect the active fields and dimensions: U, p, k, nut and epsilon for k-epsilon; omega instead of epsilon for SST. Explain their roles.
3. Replace SET_WALL_CONDITION in the wall-patch regex entries of k, nut and epsilon/omega. Add the required value entries. Choose conditions consistent with the requested wall treatment. U already has noSlip.
4. Uncomment the TODO-marked diagnostic includes in system/controlDict, including wallShearStress. uBulk enables both inlet and outlet measurements. Check what each diagnostic reports.

## Run each case manually

Load OpenCFD OpenFOAM v2412 in your allocated compute session. No shell helper scripts are supplied.

Run the commands individually and inspect each log before proceeding. Start in a fresh extracted case directory, for example:

```bash
cd 01_kEpsilon_wallFunctions/step
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
```

Confirm that mesh generation succeeded and review `log.checkMesh`. Resolve any failed checks before solving. The supplied inlet data are already installed. Do not rebuild a mesh over existing solution fields.

For a four-core run, check `numberOfSubdomains 4;` in `system/decomposeParDict`, then execute each command in turn:

```bash
decomposePar > log.decomposePar 2>&1
mpirun -np 4 simpleFoam -parallel > log.simpleFoam 2>&1
reconstructPar > log.reconstructPar 2>&1
```

Wait for the solver to finish before reconstructing. Reconstruction without `-latestTime` retains all saved iterations for convergence comparisons. For a serial run, use `simpleFoam > log.simpleFoam 2>&1` instead of decomposition, MPI and reconstruction.

After solving and, for a parallel run, reconstructing:

```bash
simpleFoam -postProcess -func velocityProfiles -latestTime > log.profiles 2>&1
simpleFoam -postProcess -func wallShearStress -latestTime > log.wallShearStress 2>&1
```

Check that the sampled profiles and wall-shear fields were written. Repeat these steps in each of the other two supplied step directories. Use at most four cores total, including concurrent runs. The allocated cores, `numberOfSubdomains` and MPI process count must agree. Run in an allocated compute session, not on the login node.

## Inlet and numerical conventions

All cases use one common resolved SST channel profile. Sampling coordinates differ between meshes. Velocity is normalized slightly to preserve the same discrete Ub=2.0424 m/s; mapping.json records this correction. The epsilon inlet is derived from epsilon=0.09*k*omega. Do not copy the inlet folder from one mesh into another.

The supplied solver relaxation is p/U/turbulence = 0.3/0.5/0.5, with at most 100 inner linear iterations. The case cap is 10000 SIMPLE iterations. Some runs may stop earlier upon meeting residual criteria. Reaching the cap is not convergence: quantify residual trends, mass balance, profile changes and reattachment stability; report remaining uncertainty. You are not required to extend beyond 10000 iterations.

The instructor has exercised the completed configurations in v2412. This student package intentionally requires setup. Wall-function limitations remain near the step and where yPlus is low. Inspect spatial distributions; do not interpret a low value near separation as proof of wall resolution.

## Post-processing and cleanup

postprocess_starter.py demonstrates reading a sampled velocity profile, normalizing it and comparing with the supplied DNS data. Extend it for the required stations and diagnostics. It does not contain the instructor results or reattachment answers.

Keep the processor directories until reconstruction has succeeded and the saved serial fields have been checked. Cleanup is optional. For the supplied four-core, uncollated setup, after the solver has stopped and all required times have been reconstructed, you may remove only the parallel directories from inside that case:

```bash
rm -r processor0 processor1 processor2 processor3
```

This command deletes the decomposed copies; do not use it before checking reconstruction. Keep the serial result directories, mesh, logs and postProcessing. For a different processor count, name only the corresponding processor directories.

Use the assignment PDF for deliverables and the course guide for detailed setup:
https://mcgillteaching.github.io/MECH501_tutorial/tutorials/assignment-03-openfoam.html

DNS CSVs are normalized and attributed in the original tutorial to Pont-Vilchez et al. (2019), doi:10.1017/jfm.2018.1000.
